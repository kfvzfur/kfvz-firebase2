//
//  AddPhotoViewController.swift
//  FirestoreDemo
//
//  Created by SHIH-YING PAN on 2019/5/21.
//  Copyright © 2019 SHIH-YING PAN. All rights reserved.
//

import UIKit
import Firebase

class AddPhotoViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    @IBOutlet weak var activityIndicatorView: UIActivityIndicatorView!
    
    @IBOutlet weak var photoButton: UIButton!
    @IBOutlet weak var textField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    }
    
    func upload() {
        activityIndicatorView.startAnimating()
        let db = Firestore.firestore()
        let data: [String: Any] = ["message": textField.text!]
        var photoReference: DocumentReference?
        photoReference = db.collection("photos").addDocument(data: data) { (error) in
            guard error == nil else {
                self.activityIndicatorView.stopAnimating()
                return
            }
            
            let storageReference = Storage.storage().reference()
            let fileReference = storageReference.child(UUID().uuidString + ".jpg")
            let image = self.photoButton.image(for: .normal)
            if let data = image?.jpegData(compressionQuality: 0.8) {
                fileReference.putData(data, metadata: nil) { (metadata, error) in
                    guard let _ = metadata, error == nil else {
                        self.activityIndicatorView.stopAnimating()
                        return
                    }
                    fileReference.downloadURL(completion: { (url, error) in
                        guard let downloadURL = url else {
                            self.activityIndicatorView.stopAnimating()
                            return
                        }
                        photoReference?.updateData(["photoUrl": downloadURL.absoluteString])
                        self.navigationController?.popViewController(animated: true)
                    })
                }
            }
        }
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let image = info[.originalImage] as? UIImage
        photoButton.setImage(image, for: .normal)
        photoButton.imageView?.contentMode = .scaleAspectFill
        photoButton.setTitle(nil, for: .normal)
        dismiss(animated: true, completion: nil)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    

    @IBAction func save(_ sender: Any) {
        
        upload()
    }
    @IBAction func selectPhoto(_ sender: Any) {
        let imagepicker = UIImagePickerController()
        imagepicker.sourceType = .photoLibrary
        imagepicker.delegate = self
        present(imagepicker, animated: true, completion: nil)
    }
}
